"use client";
import Link from "next/link";
const apps = [
 { id:"INST-2026-001", name:"Extension of Approval", date:"26 Oct 2026", status:"Under Review" },
 { id:"INST-2026-002", name:"Faculty Details", date:"25 Oct 2026", status:"Pending" },
 { id:"INST-2026-003", name:"Infrastructure Report", date:"24 Oct 2026", status:"Verified" },
 { id:"INST-2026-004", name:"Affiliation Certificate", date:"23 Oct 2026", status:"Flagged" },
];
export default function InstitutionOverview(){
 const counts={total:apps.length,verified:apps.filter(a=>a.status==="Verified").length,pending:apps.filter(a=>a.status==="Pending").length,flagged:apps.filter(a=>a.status==="Flagged").length};
 return <>
  <div className="iw-heading-row"><div><div className="iw-eyebrow">INSTITUTION WORKSPACE</div><h1>Welcome to your <span>workspace.</span></h1><p>Track your applications, manage documents, and review verification progress.</p></div><div className="iw-actions"><Link className="iw-btn" href="/institution/dashboard/reports">Export / view reports</Link><Link className="iw-btn iw-btn-primary" href="/institution/dashboard/documents">＋ Add document</Link></div></div>
  <div className="iw-notice"><span>Viewing <strong>Overview</strong> in institution demo mode.</span><Link href="/institution/dashboard/applications">View applications →</Link></div>
  <section className="iw-metrics">
   <Metric label="Total applications" value={counts.total} icon="▤" note="Sample applications" />
   <Metric label="Verified documents" value={counts.verified} icon="✓" tone="green" note="Verified records" />
   <Metric label="Pending review" value={counts.pending} icon="◷" tone="amber" note="Awaiting action" />
   <Metric label="Flagged for review" value={counts.flagged} icon="!" tone="red" note="Needs attention" />
  </section>
  <section className="iw-two-col">
   <article className="iw-card iw-panel"><div className="iw-panel-heading"><div><h2>Document verification activity</h2><p>Illustrative sample activity for the last 7 days</p></div><select className="iw-select" aria-label="Chart period" defaultValue="7"><option value="7">Last 7 days</option><option value="30">Last 30 days</option><option value="90">Last 90 days</option></select></div><div className="iw-chart">{[52,70,44,82,61,93,75].map((h,i)=><div className="iw-chart-col" key={i}><span className="iw-bar" style={{height:`${h}%`}}/><span className="iw-bar pending" style={{height:`${Math.max(15,h/3)}%`}}/></div>)}</div><div className="iw-chart-labels"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div><p className="iw-muted">Demo chart only — not live analytics.</p></article>
   <article className="iw-card iw-panel"><div className="iw-panel-heading"><div><h2>Verification readiness</h2><p>Illustrative dashboard indicators</p></div><span className="iw-pill">DEMO</span></div><div className="iw-insight-box"><div className="iw-score-row"><div><div className="iw-muted">Readiness score</div><div className="iw-score">86<small>/100</small></div></div><div className="iw-ring"><span>86%</span></div></div><div className="iw-progress"><span style={{width:"86%"}}/></div></div><p className="iw-muted">No AI model has analysed your documents. These values are examples only.</p><Link className="iw-btn iw-btn-primary" href="/institution/dashboard/verification">Open verification queue →</Link></article>
  </section>
  <section className="iw-card"><div className="iw-panel"><div className="iw-panel-heading"><div><h2>Recent applications</h2><p>Review the status of your latest submissions.</p></div><Link className="iw-btn" href="/institution/dashboard/applications">View all</Link></div></div><div className="iw-table-wrap"><table className="iw-table"><thead><tr><th>APPLICATION ID</th><th>APPLICATION / DOCUMENT</th><th>SUBMITTED</th><th>STATUS</th></tr></thead><tbody>{apps.slice(0,4).map(a=><tr key={a.id}><td><span className="iw-app-id">{a.id}</span></td><td><div className="iw-doc-cell"><span className="iw-doc-icon">▤</span><div><strong>{a.name}</strong><small>Institution submission</small></div></div></td><td>{a.date}</td><td><Status status={a.status}/></td></tr>)}</tbody></table></div><div className="iw-panel"><span className="iw-muted">Sample data · Not live AICTE records</span></div></section>
  <footer className="iw-footer"><span>© 2026 AICTE Smart Verify</span><span>Institution portal · Frontend prototype</span></footer>
 </>;
}
function Metric({label,value,icon,tone="",note}:{label:string;value:number;icon:string;tone?:string;note:string}){return <article className="iw-card iw-metric"><div className="iw-metric-top"><span>{label}</span><span className={`iw-metric-icon ${tone}`}>{icon}</span></div><div className="iw-metric-value">{value}</div><div><span className={`iw-pill ${tone}`}>{tone==="green"?"Verified":tone==="amber"?"Awaiting action":tone==="red"?"Attention":"Demo data"}</span><span className="iw-muted">{note}</span></div>{tone!==""&&<div className={`iw-progress ${tone==="amber"?"amber":""}`}><span style={{width:tone==="green"?"78%":tone==="amber"?"43%":"30%"}}/></div>}</article>}
function Status({status}:{status:string}){const cls=status==="Verified"?"verified":status==="Pending"?"pending":status==="Flagged"?"flagged":"review";return <span className={`iw-status ${cls}`}>{status}</span>}
