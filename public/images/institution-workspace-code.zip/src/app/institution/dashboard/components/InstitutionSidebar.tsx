"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const mainLinks = [
  { label: "Overview", href: "/institution/dashboard", icon: "▦" },
  { label: "My Applications", href: "/institution/dashboard/applications", icon: "▤", count: true },
  { label: "Document Verification", href: "/institution/dashboard/verification", icon: "✓" },
  { label: "My Documents", href: "/institution/dashboard/documents", icon: "▧" },
  { label: "Verification Reports", href: "/institution/dashboard/reports", icon: "⌁" },
];
const accountLinks = [
  { label: "Notifications", href: "/institution/dashboard/notifications", icon: "♧" },
  { label: "Institution Profile", href: "/institution/dashboard/profile", icon: "⚙" },
];

export default function InstitutionSidebar() {
  const pathname = usePathname();
  const isActive = (href: string) => href === "/institution/dashboard" ? pathname === href : pathname === href || pathname.startsWith(href + "/");
  return <aside className="iw-sidebar">
    <Link href="/institution/dashboard" className="iw-brand">
      <span className="iw-logo"><img src="/images/aicte-logo.png" alt="AICTE logo" /></span>
      <span className="iw-brand-text"><strong>AICTE</strong><small>SMART VERIFY</small></span><span className="iw-chevron">⌄</span>
    </Link>
    <div className="iw-workspace-card"><span className="iw-workspace-avatar">I</span><span><strong>Institution Workspace</strong><small>Institution portal</small></span><span className="iw-chevron">⌄</span></div>
    <div className="iw-nav-label">INSTITUTION PORTAL</div>
    <nav className="iw-nav" aria-label="Institution portal">
      {mainLinks.map(item => <Link key={item.href} href={item.href} className={`iw-nav-link ${isActive(item.href) ? "active" : ""}`}>
        <span className="iw-nav-icon" aria-hidden="true">{item.icon}</span><span className="iw-nav-text">{item.label}</span>
        {item.count && <span className="iw-count">{typeof window === "undefined" ? 4 : (localStorage.getItem("iw-app-count") || "4")}</span>}
      </Link>)}
    </nav>
    <div className="iw-nav-label iw-account-label">ACCOUNT</div>
    <nav className="iw-nav" aria-label="Account">
      {accountLinks.map(item => <Link key={item.href} href={item.href} className={`iw-nav-link ${isActive(item.href) ? "active" : ""}`}><span className="iw-nav-icon" aria-hidden="true">{item.icon}</span><span className="iw-nav-text">{item.label}</span>{item.label === "Notifications" && <span className="iw-notice-dot" />}</Link>)}
    </nav>
    <div className="iw-sidebar-spacer" />
    <div className="iw-help-card"><span className="iw-help-mark">?</span><strong>Need assistance?</strong><p>Find guidance for document verification and submissions.</p><button type="button" onClick={() => window.alert("Help centre demo: contact your portal administrator for assistance.")}>Visit help centre <span>→</span></button></div>
    <div className="iw-sidebar-footer"><span className="iw-online-dot" />Frontend prototype</div>
  </aside>;
}
